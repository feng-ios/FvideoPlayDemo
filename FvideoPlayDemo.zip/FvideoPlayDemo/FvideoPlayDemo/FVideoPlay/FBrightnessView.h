//
//  FBrightnessView.h
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/12.
//  Copyright © 2017年 PFYH. All rights reserved.
//
/********************** 亮度******************************/
#import <UIKit/UIKit.h>

@interface FBrightnessView : UIView

+ (instancetype)sharedSoundView;

@end
