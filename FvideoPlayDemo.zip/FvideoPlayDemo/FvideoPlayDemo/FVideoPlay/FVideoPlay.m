//
//  ZSPlayerView.m
//  testIJK
//
//  Created by zsj1992 on 16/12/20.
//  Copyright © 2016年 bjhj. All rights reserved.
//

#import "FVideoPlay.h"
#import "FButton.h"
#import "FLoading.h"
#import <MediaPlayer/MediaPlayer.h>
#import "AFNetworkReachabilityManager.h"

// 滑动方向
typedef NS_ENUM(NSInteger, CameraMoveDirection) {
    kCameraMoveDirectionNone,
    kCameraMoveDirectionUp,
    kCameraMoveDirectionDown,
    kCameraMoveDirectionRight,
    kCameraMoveDirectionLeft,
};

CGFloat const gestureMinimumTranslation = 5.0;

#define CELL_H (SCREEN_W / 16 * 9 + 10)
#define MAGIN_W ([UIScreen mainScreen].bounds.size.width / 3)

#define backTopSpace (SCREEN_H > 736) ? 20 :10


@interface FVideoPlay()<UIGestureRecognizerDelegate>{
    UIImageView * _placeHolderImgView;
}

//工具蒙版
@property (nonatomic,strong)FButton * btnLock;
@property (nonatomic,strong)FLoading * loading;

//标题栏
@property (nonatomic,strong)FButton * btnBack;
@property (nonatomic,strong)UILabel * lblTitle;

//工具蒙版
@property (nonatomic,strong)FButton *btnPlay;
@property (nonatomic,strong)FButton *btnFullScreen;
@property (nonatomic,strong)UILabel * lblCurrentTime;
@property (nonatomic,strong)UILabel * lblTotalTime;
@property (nonatomic,strong)UISlider * slider;//滑块
@property (nonatomic,strong)UIProgressView * progressView;//进度条




@property (nonatomic, assign) CameraMoveDirection        direction;            // 方向
@property (nonatomic, assign) CGPoint                    location;            // 开始位置
@property (nonatomic, assign) float                        volume;                // 当前音量
@property (nonatomic, assign) CGFloat                    brightness;            // 当前亮度
@property (nonatomic, assign) CGPoint                    curretn;            // 实时位置

@property (nonatomic, assign) BOOL Isfinish;/** 是否播放完成 */


@end

@implementation FVideoPlay


#pragma mark-初始化方法
-(instancetype)initWithFrame:(CGRect)frame delegate:(id)delegate model:(FVideoModel *)model{
    if (self = [super initWithFrame:frame]) {
        self.fullScreenDelegate = delegate;
        self.backDelegate = delegate;
        [self setupPlayerViewWithModel:model];
        //    [self startReachability];
    }
    return self;
}

/**做网络提醒和监听: */
- (void)startReachability {
    //1.初始化
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    //2.开始监听网络的状态
    [manager startMonitoring];
    
    //3.设置网络状态改变的回调
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
            {
                alert.message = @"当前是未知网络";
                if (self.btnPlay.selected == NO) {
                    [self play:self.btnPlay];
                } else {
                    [self.player pause];
                }
            }
                break;
            case AFNetworkReachabilityStatusNotReachable:
            {
                alert.message = @"无网络连接";
                if (self.btnPlay.selected == NO) {
                    [self play:self.btnPlay];
                } else {
                    [self.player pause];
                }
            }
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
            {
                alert.message = @"手机蜂窝网络";
                if (self.btnPlay.selected == NO) {
                    [self.player play];
                }
            }
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
            {
                alert.message = @"当前WiFi网络";
                if (self.btnPlay.selected == NO) {
                    [self.player play];
                }
            }
                break;
            default:
                break;
        }
        
        [alert show];
    }];
    
}


#pragma mark-设置url
//-(void)setUrl:(NSString *)url{
//    _url = url;
//
//}


#pragma mark-初始化playerView
-(void)setupPlayerViewWithModel:(FVideoModel *)model{
    
    //  添加声音 和 亮度  手势
    [self addPanGesture];
    // 视频播放的操作：
    self.url = model.url;
    _playerItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:self.url]];
    _player = [AVPlayer playerWithPlayerItem:self.playerItem];// model.context
    if([[UIDevice currentDevice] systemVersion].intValue>=10){
        //      增加下面这行可以解决iOS10兼容性问题了
        if (@available(iOS 10.0, *)) {
            self.player.automaticallyWaitsToMinimizeStalling = NO;
        } else {
            // Fallback on earlier versions
        }
    }
    //获取播放视图
    self.playerView =  [[UIView alloc] init];
    [self addSubview:self.playerView];
    self.playerView.frame = self.bounds;
    _playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
    _playerLayer.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame));
    _playerLayer.videoGravity = AVLayerVideoGravityResize;
    [self.playerView.layer addSublayer:self.playerLayer];
    [self.player play];
    //添加通知和观察者：
    [self installNotificationObservers];
    
    //把播放视图插到最上面去
    //    [self insertSubview:self.playerView atIndex:0];
    
    // 这个是视频为播放出来时添加的掩盖:
    _placeHolderImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"blackBG"]];
    _placeHolderImgView.backgroundColor = [UIColor clearColor];
    [self.playerView addSubview:_placeHolderImgView];
    [_placeHolderImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.equalTo(self.playerView);
    }];
    
    
    // 添加轻拍手势：显示进度条 和按钮 ：
    UITapGestureRecognizer * tap  = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(playerViewTap:)];
    tap.delegate = self;
    [self.playerView addGestureRecognizer:tap];
    
    // 添加其他的点击事件：
    self.cover = [[UIView alloc]init];
    self.cover.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.1];
    [self.playerView addSubview:self.cover];
    [self.cover mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.equalTo(self.playerView);
    }];
    
    
    //返回按钮
    _btnBack = [[FButton alloc]init];
    [_btnBack setImage:[UIImage imageNamed:@"back"] forState:(UIControlStateNormal)];
    [_cover addSubview:_btnBack];
    [_btnBack mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_cover);
        make.top.equalTo(_cover).offset(backTopSpace);
        make.width.height.mas_equalTo(40);
    }];
    [_btnBack addTarget:self action:@selector(back:) forControlEvents:(UIControlEventTouchUpInside)];
    
    //视频信息
    _lblTitle = [[UILabel alloc]init];
    _lblTitle.font = [UIFont systemFontOfSize:14];
    _lblTitle.textColor = [UIColor whiteColor];
    _lblTitle.text =@"";
    [_cover addSubview:_lblTitle];
    [_lblTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_btnBack.mas_right);
        make.centerY.equalTo(_btnBack);
    }];
    
    
    
    /***********************************************************/
    
    //全屏按钮
    _btnFullScreen = [[FButton alloc]init];
    [_btnFullScreen setImage:[UIImage imageNamed:@"fullScreen"] forState:(UIControlStateNormal)];
    [_btnFullScreen setImage:[UIImage imageNamed:@"quiteScreen"] forState:(UIControlStateSelected)];
    [_cover addSubview:_btnFullScreen];
    [_btnFullScreen mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_cover);
        make.bottom.equalTo(_cover);
        make.width.height.mas_equalTo(50);
    }];
    [_btnFullScreen addTarget:self action:@selector(fullScreen:) forControlEvents:(UIControlEventTouchUpInside)];
    
    
    //视频当前时间
    _lblCurrentTime = [[UILabel alloc]init];
    _lblCurrentTime.font = [UIFont systemFontOfSize:15];
    _lblCurrentTime.text = @"00:00:00";
    _lblCurrentTime.textAlignment = NSTextAlignmentLeft;
    _lblCurrentTime.textColor = [UIColor whiteColor];
    [_cover addSubview:_lblCurrentTime];
    [_lblCurrentTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_cover).offset(10);
        make.centerY.equalTo(_btnFullScreen);
        make.width.mas_equalTo(65);
    }];
    
    //视频总时长
    _lblTotalTime = [[UILabel alloc]init];
    _lblTotalTime.font = [UIFont systemFontOfSize:15];
    _lblTotalTime.text = @"00:00:00";
    _lblTotalTime.textAlignment = NSTextAlignmentRight;
    _lblTotalTime.textColor = [UIColor whiteColor];
    [_cover addSubview:_lblTotalTime];
    [_lblTotalTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(_btnFullScreen.mas_left);
        make.centerY.equalTo(_btnFullScreen);
        make.width.mas_equalTo(65);
        
    }];
    
    
    //缓冲进度条
    _progressView = [[UIProgressView alloc]init];
    [_cover addSubview:_progressView];
    _progressView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [_progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_lblCurrentTime.mas_right).offset(5);
        make.right.equalTo(_lblTotalTime.mas_left).offset(-5);
        make.centerY.equalTo(_btnFullScreen);//progressView向下一个像素
    }];
    _progressView.tintColor = [UIColor whiteColor];
    [_progressView setProgress:0];
    
    
    
    //滑块
    _slider = [[UISlider alloc]init];
    _slider.userInteractionEnabled = YES;
    _slider.continuous = YES;//设置为NO,只有在手指离开的时候调用valueChange
    [_slider addTarget:self action:@selector(sliderValuechange:) forControlEvents:UIControlEventValueChanged];
    UITapGestureRecognizer * sliderTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(sliderTap:)];
    [_slider addGestureRecognizer:sliderTap];
    [_cover addSubview:_slider];
    [_slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(_progressView);
        make.centerY.equalTo(_progressView).offset(-1);
    }];
    _slider.minimumTrackTintColor = [UIColor whiteColor];
    _slider.maximumTrackTintColor = [UIColor clearColor];
    UIImage * image = [self createImageWithColor:[UIColor whiteColor]];
    UIImage * circleImage = [self circleImageWithImage:image borderWidth:0 borderColor:[UIColor clearColor]];
    [_slider setThumbImage:circleImage forState:(UIControlStateNormal)];
    [self layoutIfNeeded];
    
    
    //使用系统菊花:
    self.activity = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    _activity.center = _playerView.center;
    [self addSubview:_activity];
    [_activity startAnimating];
    
    //loading的位置用计算的...
//    _loading = [[FLoading alloc]init];
//    [_cover addSubview:_loading];
//    [_loading mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.centerY.equalTo(_cover);
//        make.width.height.mas_equalTo(100);
//
//    }];
//    [_cover layoutIfNeeded];
//    _loading.frame = _loading.frame;
    //////////////////////随加载状态的改变而改变
    
    
    //播放按钮
    _btnPlay = [[FButton alloc]init];
    [_cover addSubview:_btnPlay];
    [_btnPlay setImage:[UIImage imageNamed:@"pause"] forState:(UIControlStateNormal)];
    [_btnPlay setImage:[UIImage imageNamed:@"play"] forState:(UIControlStateSelected)];
    [_btnPlay addTarget:self action:@selector(play:) forControlEvents:(UIControlEventTouchUpInside)];
    [_btnPlay mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.centerY.equalTo(_cover);
        make.width.height.mas_equalTo(100);
    }];
    
    //锁屏:
    _btnLock = [[FButton alloc]init];
    [_btnLock setImage:[UIImage imageNamed:@"lock1"] forState:(UIControlStateNormal)];
    [_btnLock setImage:[UIImage imageNamed:@"lockSel1"] forState:(UIControlStateSelected)];
    //[_btnLock addTarget:self action:@selector(lock:) forControlEvents:(UIControlEventTouchUpInside)];
    [_cover addSubview:_btnLock];
    [_btnLock mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_btnPlay);
        make.left.equalTo(_btnBack);
        make.width.height.mas_equalTo(40);
    }];
    
    
    //控件隐藏着：
    _btnPlay.hidden = YES;
    _lblTotalTime.hidden = YES;
    _lblCurrentTime.hidden = YES;
    _slider.hidden = YES;
    _progressView.hidden = YES;
    
    
}



//加载状态发生改变的时候切换
-(void)changeState{
    //移除加载条
    //    [_loading removeFromSuperview];
//    _loading.animationStop = YES;
    
    //改变隐藏的状态
    _lblCurrentTime.hidden = !_lblCurrentTime.hidden;
    _lblTotalTime.hidden = !_lblTotalTime.hidden;
    _slider.hidden = !_slider.hidden;
    _progressView.hidden = !_progressView.hidden;
    _btnPlay.hidden = !_progressView;
    
}



BOOL _hideTool;/** 隐藏工具 */
#pragma mark tap手势  点击了playerView 手势处理
-(void)playerViewTap:(UITapGestureRecognizer *)recognizer{
    
    //每次点击取消还在进程中的隐藏方法
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hide) object:nil];
    _hideTool = !_hideTool;
    
    [UIView animateWithDuration:0.25 animations:^{
        if (_hideTool) {
            self.cover.alpha = 0;
        }else{
            self.cover.alpha = 1;
        }
    } completion:^(BOOL finished) {
        if (_hideTool) {
            self.cover.hidden = YES;
        }else{
            self.cover.hidden = NO;
            //如果最后没隐藏,在调用隐藏的代码
            [self performSelector:@selector(hide) withObject:nil afterDelay:4];
        }
    }];
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isKindOfClass:[FButton class]]){
        return NO;
    }
    return YES;
}


#pragma mark-隐藏cover

-(void)hide{
    [UIView animateWithDuration:0.25 animations:^{
        self.cover.alpha =0 ;
    }completion:^(BOOL finished) {
        self.cover.hidden = YES;
        _hideTool = YES;
    }];
}


#pragma mark-touchBengan
CGPoint startP;
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    NSLog(@"touchbegan=======%d",_hideTool);
    
    //    startP = [[touches anyObject] locationInView:self.playerView];
    
    if (!_hideTool) {
        [self hide];
    }
}


-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}

//点击结束
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}

//点击取消
-(void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
}





#pragma mark 设置 音量条 ,  亮度条
#pragma mark -- addPanGesture

- (void)addPanGesture {
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(panAction:)];
    pan.delegate = self;
    [self addGestureRecognizer:pan];
}

/**  */
- (void)panAction:(UIPanGestureRecognizer *)recognizer {
    
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        self.direction    = kCameraMoveDirectionNone;                                // 无方向
        self.location    = [recognizer locationInView:self];                        // 开始滑动位置
        self.volume        = self.player.volume;                                    // 获取当前音量
        self.brightness = [UIScreen mainScreen].brightness;                        // 获取当前亮度
    }
    
    CGPoint translation = [recognizer translationInView:self];        // 事实移动位置 增量
    self.direction    = [self determineCameraDirectionIfNeeded:translation];//获取滑动方向
    self.curretn    = [recognizer locationInView:self];//实时位置
    
    // 亮度/声音调节
    if (self.direction == 1 || self.direction == 2) {//上下滑动
        
        //根据区域来决定是亮度 还是声音
        if (self.location.x <= MAGIN_W) {// 亮度
            float currentBrightness = self.brightness + ((self.location.y - self.curretn.y) / self.frame.size.height);
            if (currentBrightness <= 0 ) {
                currentBrightness = 0;
            } else if(currentBrightness >= 1) {
                currentBrightness = 1;
            }
            [UIScreen mainScreen].brightness = currentBrightness;
            
        } else if (self.location.x >= self.frame.size.width - MAGIN_W) {// 声音
            
            float currentVolume = self.volume + ((self.location.y - self.curretn.y) / self.frame.size.height);
            if (currentVolume <= 0 ) {
                currentVolume = 0;
            } else if(currentVolume >= 1) {
                currentVolume = 1;
            }
            [self.player setVolume:currentVolume];
            
            [self setSystemVolme:currentVolume];//设置当前音量
        }
        
    } else if(self.direction == 3 || self.direction == 4) {// 进度调节
        //        translation.x    移动偏移量
        //        velocity.x        移动速度
        
        NSLog(@"==== %@", NSStringFromCGPoint(self.curretn));
        if (self.curretn.y >= (self.bounds.size.height - 30)) {
            return;
        }
        CGFloat time        = 300;
        CGFloat speed        = time / self.frame.size.width;            // 移动快进速度
        long add            =  (long)(translation.x) *speed;
        CMTime currentTime    = self.player.currentTime;
        CMTime addTime        = CMTimeMake(add, 1);
        CMTime newTime        = CMTimeAdd(currentTime, addTime);
        if (recognizer.state == UIGestureRecognizerStateEnded) {
            
            if (CMTimeRangeContainsTime(CMTimeRangeMake(kCMTimeZero, self.playerItem.duration), newTime)) {
                [self.player seekToTime:newTime completionHandler:^(BOOL finished) {//在0-1区间
                }];
            } else if (newTime.value <=0) {//小于0
                [self.player seekToTime:kCMTimeZero completionHandler:^(BOOL finished) {
                }];
            } else if ((newTime.value / newTime.timescale) >= (self.playerItem.duration.value / self.playerItem.duration.timescale)) {//大于1
                [self.player seekToTime:self.playerItem.duration completionHandler:^(BOOL finished) {
                }];
            }
        }
    }
}

/** 获取滑动方向 */
- ( CameraMoveDirection )determineCameraDirectionIfNeeded:( CGPoint )translation {
    if (self.direction != kCameraMoveDirectionNone)
        return self.direction;
    
    if (fabs(translation.x) > gestureMinimumTranslation) {
        
        BOOL gestureHorizontal = NO;
        if (translation.y == 0.0) {
            gestureHorizontal = YES;
        }else {
            gestureHorizontal = (fabs(translation.x / translation.y) > 5.0);
        }
        
        if(gestureHorizontal) {
            if (translation.x > 0.0)
                return kCameraMoveDirectionRight;
            else
                return kCameraMoveDirectionLeft;
        }
    }
    else if (fabs(translation.y) > gestureMinimumTranslation)
        
    {
        BOOL gestureVertical = NO;
        if (translation.x == 0.0) {
            gestureVertical = YES;
        } else {
            gestureVertical = (fabs(translation.y / translation.x) > 5.0);
        }
        if(gestureVertical) {
            if (translation.y > 0.0)
                return kCameraMoveDirectionDown;
            else
                return kCameraMoveDirectionUp;
        }
    }
    return self.direction;
}

- (CGFloat)getSystemVolume {
    MPMusicPlayerController *musicPlayer;
    musicPlayer = [MPMusicPlayerController applicationMusicPlayer];
    return musicPlayer.volume;
}

- (void)setSystemVolme:(float)currentVolume {
    MPMusicPlayerController *musicPlayer;
    musicPlayer = [MPMusicPlayerController applicationMusicPlayer];
    [musicPlayer setVolume:currentVolume];
}




#pragma mark - 点击事件处理：
#pragma mark --锁定
-(void)lock:(FButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        for (UIView * subView in _cover.subviews) {
            subView.alpha = 0;
        }
        sender.alpha = 1;
    }else{
    }
}

#pragma --点击了返回按钮
-(void)back:(UIButton *)sender{
//    _loading.animationStop = YES;
    [_loading removeFromSuperview];
    
    if (self.backDelegate && [self.backDelegate respondsToSelector:@selector(btnBackClick:)]) {
        [self.backDelegate btnBackClick:sender];
    }
}

#pragma mark--暂停/播放
-(void)play:(FButton *)sender{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hide) object:nil];
    sender.selected = !sender.selected;
    if (sender.selected) {
        [self.player pause];
        _Isfinish = YES;
    }else{
        [self.player play];
        _Isfinish = NO;
    }
    [self performSelector:@selector(hide) withObject:nil afterDelay:4];
    
}

#pragma mark --点击了全屏按钮
- (void)fullScreen:(FButton *)sender {
    NSLog(@"点击全屏");
    sender.selected = !sender.selected;
    if (self.fullScreenDelegate&&[self.fullScreenDelegate respondsToSelector:@selector(btnFullScreenDidClick:)]) {
        [self.fullScreenDelegate btnFullScreenDidClick:sender];
    }
}


#pragma mark--点击滑块
-(void)sliderTap:(UITapGestureRecognizer *)tap{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hide) object:nil];
    UISlider * slider = (UISlider *)tap.view;
    CGPoint point = [tap locationInView:slider];
    [_slider setValue:point.x/_slider.bounds.size.width*1 animated:YES];
    [self performSelector:@selector(hide) withObject:nil afterDelay:4];
    
}


#pragma mark 滑块值发生改变
-(void)sliderValuechange:(UISlider *)sender{
    NSLog(@"sliderValuechange");
    //取消收回工具栏的动作
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hide) object:nil];
    [self performSelector:@selector(hide) withObject:nil afterDelay:4];
    //拖动改变视频播放进度
    if (self.player.status == AVPlayerStatusReadyToPlay) {
        //计算出拖动的当前秒数
        CGFloat total = (CGFloat)self.playerItem.duration.value / self.playerItem.duration.timescale;
        NSInteger dragedSeconds = floorf(total * _slider.value);
        //    NSLog(@"dragedSeconds:%ld",dragedSeconds);
        //转换成CMTime才能给player来控制播放进度
        CMTime dragedCMTime = CMTimeMake(dragedSeconds, 1);
        

        if (self.btnPlay.selected == NO) {
            [self play:self.btnPlay];
        } else {
            [self.player pause];
        }
        
        [self.player seekToTime:dragedCMTime completionHandler:^(BOOL finish){
            if (self.btnPlay.selected == YES) {
                [self play:self.btnPlay];
            } else {
                [self.player play];
            }
            
        }];
        
    }
    
}


BOOL _hideToolbar;
NSTimer * timer;
#pragma mark  观察者
#pragma mark --加载状态改变
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    
    //    NSLog(@"keyPath == %@,%@,%@,%@",keyPath,object,change,context);
    if ([keyPath isEqualToString:@"status"]) {
        
        // 获取 AVPlayerItemStatus
        AVPlayerItemStatus itemStatus = self.playerItem.status;
        switch (itemStatus) {
            case AVPlayerItemStatusReadyToPlay:{
                NSLog(@"AVPlayerItemStatusReadyToPlay");
//                _loading.animationStop = YES;
            }
                break;
            case AVPlayerItemStatusUnknown:
            {
                NSLog(@"AVPlayerItemStatusUnknown");
                //                [self.player replaceCurrentItemWithPlayerItem:self.playerItem];
                //                [self.player play];
            }
                break;
            case AVPlayerItemStatusFailed:
            {
//                _loading.animationStop = NO;
                NSLog(@"AVPlayerItemStatusFailed");
                [self.player replaceCurrentItemWithPlayerItem:self.playerItem];
                if (self.btnPlay.selected == YES) {
                    [self play:self.btnPlay];
                } else {
                    [self.player play];
                }
                NSLog(@"self.playerItem.error == %@",self.playerItem.error);
            }
                break;
            default:
                break;
        }
        
        //播放的状态:
        AVPlayerStatus status= [[change objectForKey:@"new"] intValue];
        switch (status) {
            case AVPlayerStatusReadyToPlay:
            {
//                _loading.animationStop = YES;
                //               NSLog(@"%@",@" AVPlayerStatus AVPlayerStatusReadyToPlay");
                //视频开始播放的时候开启计时器
                if (timer == nil) {
                    timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(update) userInfo:nil repeats:YES];
                    [self performSelector:@selector(hide) withObject:nil afterDelay:4];
                    [_placeHolderImgView removeFromSuperview];
                    [self changeState];
                }
            }
                break;
            case AVPlayerStatusUnknown:
            {
                //                   NSLog(@"%@",@"AVPlayerStatus AVPlayerStatusUnknown");
            }
                break;
            case AVPlayerStatusFailed:
            {
                NSLog(@"%@",@"AVPlayerStatus AVPlayerStatusFailed");
                if (self.btnPlay.selected == NO) {
                    [self play:self.btnPlay];
                } else {
                    [self.player pause];
                }
//                _loading.animationStop = NO;
            }
                break;
            default:
                break;
        }
        
    } else if ([keyPath isEqualToString:@"loadedTimeRanges"]) {
        //        NSLog(@"self.player.reasonForWaitingToPlay == %@",self.player.reasonForWaitingToPlay);
        NSTimeInterval timeInterval = [self availableDuration];// 计算缓冲进度
        CMTime duration = self.playerItem.duration;
        CGFloat totalDuration = CMTimeGetSeconds(duration);
        [self.progressView setProgress:timeInterval / totalDuration animated:YES];
    } else if ([keyPath isEqualToString:@"playbackBufferEmpty"]) {
        NSLog(@"playbackBufferEmpty");
//        _loading.animationStop = NO;
    } else if ([keyPath isEqualToString:@"playbackLikelyToKeepUp"]) {
        NSLog(@"playbackLikelyToKeepUp");
//        _loading.animationStop = YES;
        if (!_Isfinish) {
            if (self.btnPlay.selected ==YES) {
                [self play:self.btnPlay];
            } else {
                [_player play];
            }
        }
    }
}

#pragma mark --定时器  更新方法
-(void)update{
    if (self.playerItem.duration.timescale != 0) {
        _slider.maximumValue = 1;//音乐总共时长
        _slider.value = CMTimeGetSeconds([self.playerItem currentTime]) / (self.playerItem.duration.value / self.playerItem.duration.timescale);//当前进度
        NSTimeInterval timeInterval = [self availableDuration];// 计算缓冲进度
        CMTime duration = self.playerItem.duration;
        CGFloat totalDuration = CMTimeGetSeconds(duration);
        [self.progressView setProgress:timeInterval / totalDuration animated:YES];
        
        //当前时长
        _lblCurrentTime.text = [self TimeformatFromSeconds:(NSInteger)CMTimeGetSeconds([self.player currentTime])];
        //duration 总时长
        _lblTotalTime.text = [self TimeformatFromSeconds:((NSInteger)self.playerItem.duration.value / self.playerItem.duration.timescale)];
    }
    
    if (self.player.status == AVPlayerStatusReadyToPlay) {
        [_activity stopAnimating];
    } else {
        [_activity startAnimating];
    }
}


#pragma mark --添加 观察  通知
- (void)installNotificationObservers {
    //AVPlayer播放完成通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(moviePlayDidEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    // 缓冲不足暂停播放:
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieSotpToPlay:) name:AVPlayerItemPlaybackStalledNotification object:nil];
    
    _Isfinish = NO;
    [self addAVPlayerItemObserver];
}

/**播放结束 */
- (void)moviePlayDidEnd:(NSNotification *)sender
{
    [self.player seekToTime:CMTimeMake(0, 1)];
    [self.player pause];
    _Isfinish = YES;
    if (self.btnPlay.selected == NO) {
        [self play:self.btnPlay];
    }
}

/**缓冲不足暂停播放: */
- (void)movieSotpToPlay:(NSNotification *)sender {
    if (self.btnPlay.selected  == NO) {
        [self play:self.btnPlay];
    } else {
        [self.player pause];
    }
}

/** 添加观察者*/
- (void)addAVPlayerItemObserver {
    //监控状态属性，注意AVPlayer也有一个status属性，通过监控它的status也可以获得播放状态
    [self.playerItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    //监控网络加载情况属性
    [self.playerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:nil];// 监听loadedTimeRanges属性
    // 监听缓存的状态 缓存不足 暂停：播放
    [self.playerItem addObserver:self forKeyPath:@"playbackBufferEmpty" options:NSKeyValueObservingOptionNew context:nil];
    // /由于 AVPlayer 缓存不足就会自动暂停，所以缓存充足了需要手动播放，才能继续播放
    [self.playerItem addObserver:self forKeyPath:@"playbackLikelyToKeepUp" options:NSKeyValueObservingOptionNew context:nil];
}

#pragma --移除观察者
- (void)removeAVPlayerItemObserver {
    [self.playerItem removeObserver:self forKeyPath:@"status"];
    [self.playerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
    [self.playerItem removeObserver:self forKeyPath:@"playbackLikelyToKeepUp"];
}

#pragma --移除 通知 观察者 移除视频资源
- (void)removeNotificationObservers {
    [self.player pause];
    //注意顺序:
    [self removeAVPlayerItemObserver];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemPlaybackStalledNotification object:nil];
    [self.player.currentItem cancelPendingSeeks];
    [self.player.currentItem.asset cancelLoading];
    self.playerItem = nil;
    self.player = nil;
    [self.playerLayer removeFromSuperlayer];
    self.playerLayer = nil;
    [timer invalidate];
    timer = nil;
}

#pragma mark  刷新数据  重新加载视频资源;
- (void)refreshVideoDataWithModel:(FVideoModel *)model {
    self.url = model.url;
    if (self.btnPlay.selected == NO) {
        [self play:self.btnPlay];
    } else {
        [self.player pause];
    }
    
    //先移除:
    [self removeAVPlayerItemObserver];
    self.playerItem = nil;
    _playerItem = [AVPlayerItem playerItemWithURL:[NSURL URLWithString:[self.url copy]]];
    //再添加
    [self addAVPlayerItemObserver];
    [self.player replaceCurrentItemWithPlayerItem:self.playerItem];
    [self.player seekToTime:CMTimeMake(0, 1)];
//    _loading.animationStop =NO;
    if (self.btnPlay.selected == YES) {
        [self play:self.btnPlay];
    } else {
        [self.player play];
    }
}




#pragma mark   刷新 frame
- (void)refreshFrame:(CGRect)frame {
    self.frame = frame;
    CGRect frame1 = CGRectMake(0, 0, frame.size.width, frame.size.height);
    self.playerView.frame = frame1;
    self.playerView.layer.frame = frame1;
    self.playerLayer.frame  = frame1;
}



#pragma mark-公共方法
/** 计算缓冲进度 */
- (NSTimeInterval)availableDuration {
    NSArray *loadedTimeRanges = [[self.player currentItem] loadedTimeRanges];
    CMTimeRange timeRange = [loadedTimeRanges.firstObject CMTimeRangeValue];// 获取缓冲区域
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    NSTimeInterval result = startSeconds + durationSeconds;// 计算缓冲总进度
    return result;
}


- (NSString*)TimeformatFromSeconds:(NSInteger)seconds
{
    //format of hour
    NSString *str_hour = [NSString stringWithFormat:@"%02ld",seconds/3600];
    //format of minute
    NSString *str_minute = [NSString stringWithFormat:@"%02ld",(seconds%3600)/60];
    //format of second
    NSString *str_second = [NSString stringWithFormat:@"%02ld",seconds%60];
    //format of time
    NSString *format_time = [NSString stringWithFormat:@"%@:%@:%@",str_hour,str_minute,str_second];
    return format_time;
}

//从图片
- (UIImage*) createImageWithColor:(UIColor*) color
{
    CGRect rect=CGRectMake(0,0,15,15);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}



- (UIImage *)circleImageWithImage:(UIImage *)oldImage borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor
{
    // 1.加载原图
    
    // 2.开启上下文
    CGFloat imageW = oldImage.size.width + 22 * borderWidth;
    CGFloat imageH = oldImage.size.height + 22 * borderWidth;
    CGSize imageSize = CGSizeMake(imageW, imageH);
    UIGraphicsBeginImageContextWithOptions(imageSize, NO, 0.0);
    
    // 3.取得当前的上下文,这里得到的就是上面刚创建的那个图片上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // 4.画边框(大圆)
    [borderColor set];
    CGFloat bigRadius = imageW * 0.5; // 大圆半径
    CGFloat centerX = bigRadius; // 圆心
    CGFloat centerY = bigRadius;
    CGContextAddArc(ctx, centerX, centerY, bigRadius, 0, M_PI * 2, 0);
    CGContextFillPath(ctx); // 画圆。As a side effect when you call this function, Quartz clears the current path.
    
    // 5.小圆
    CGFloat smallRadius = bigRadius - borderWidth;
    CGContextAddArc(ctx, centerX, centerY, smallRadius, 0, M_PI * 2, 0);
    // 裁剪(后面画的东西才会受裁剪的影响)
    CGContextClip(ctx);
    
    // 6.画图
    [oldImage drawInRect:CGRectMake(borderWidth, borderWidth, oldImage.size.width, oldImage.size.height)];
    // 7.取图
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    // 8.结束上下文
    UIGraphicsEndImageContext();
    
    return newImage;
}



@end
