//
//  FButton.h
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/12.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FButton : UIButton

@end
