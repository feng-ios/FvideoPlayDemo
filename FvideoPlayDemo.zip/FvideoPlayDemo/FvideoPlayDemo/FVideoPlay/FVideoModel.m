//
//  FVideoModel.m
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/24.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import "FVideoModel.h"

@implementation FVideoModel

@end
