//
//  FVideoModel.h
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/24.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FVideoModel : NSObject

@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *title;

@end
