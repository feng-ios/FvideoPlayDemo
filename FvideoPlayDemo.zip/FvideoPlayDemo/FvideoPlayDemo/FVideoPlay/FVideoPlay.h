//
//  FVideoPlay.h
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/12.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"
#import <AVFoundation/AVFoundation.h>
#import "FVideoModel.h"

#define SCREEN_W [UIScreen mainScreen].bounds.size.width
#define SCREEN_H [UIScreen mainScreen].bounds.size.height



@protocol fullScreenDelegate <NSObject>

-(void)btnFullScreenDidClick:(UIButton *)sender;

@end

@protocol backDelegate <NSObject>

-(void)btnBackClick:(UIButton *)sender;

@end

@protocol collectkDelegate <NSObject>

-(void)btnCollectClick:(UIButton *)sender;

@end

@interface FVideoPlay : UIView


@property (nonatomic,copy)NSString * url;
@property(nonatomic,strong)AVPlayer *player; // 播放属性
@property(nonatomic,strong)AVPlayerItem *playerItem; // 播放属性
@property (nonatomic, strong) AVPlayerLayer *playerLayer;/**< 播放属性 */
@property(nonatomic,strong)UIActivityIndicatorView *activity; // 系统菊花
//播放视图
@property (nonatomic,strong)UIView * playerView;


@property (nonatomic,strong)id<fullScreenDelegate> fullScreenDelegate;
@property (nonatomic,strong)id<backDelegate> backDelegate;
@property (nonatomic,strong)id<collectkDelegate> collectDelegate;

@property (nonatomic,strong)UIView * cover;


-(instancetype)initWithFrame:(CGRect)frame delegate:(id)delegate model:(FVideoModel *)model;


/** 播放新的视频: */
- (void)refreshVideoDataWithModel:(FVideoModel *)model;

/*** 刷新frame */
- (void)refreshFrame:(CGRect)frame;

/** 移除通知 */
- (void)removeNotificationObservers;
@end
