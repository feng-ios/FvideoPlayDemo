//
//  ViewController.m
//  FVideoPlay
//
//  Created by 林豪威尔 on 2017/10/12.
//  Copyright © 2017年 PFYH. All rights reserved.
//

#import "ViewController.h"
#import "FVideoPalyViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.title  =@"视频点播";
    self.view.backgroundColor = [UIColor greenColor];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    NSString * url = @"http://vodthhjzqhd.vod.126.net/vodthhjzqhd/664c94aa-aad3-4fb1-8c0b-0e3ef1dcb4f5.mp4";//http://live.hkstv.hk.lxdns.com/live/hks/playlist.m3u8
    FVideoPalyViewController * playVc = [[FVideoPalyViewController alloc]init];
    playVc.url = url;
    [self.navigationController pushViewController:playVc animated:YES];
}


@end
